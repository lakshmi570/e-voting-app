from flask import Flask, render_template, request, jsonify, redirect, url_for
import hashlib
import time
import json
import uuid
import os
from blockchain import Block, Blockchain

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Generate a secure random secret key

# Add the sum function to Jinja2 environment
app.jinja_env.globals.update(sum=sum)

# Initialize blockchain
blockchain = Blockchain()
voters = {}  # Stores voter_id -> voter_hash
candidates = ["Shreya", "Swathi", "Bhavana"]
candidate_info = {
    "Shreya": {"icon": "fa-seedling", "color": "green", "description": ""},
    "Swathi": {"icon": "fa-book", "color": "blue", "description": ""},
    "Bhavana": {"icon": "fa-female", "color": "purple", "description": ""}
}
election_active = False
results_declared = False
declared_winner = None
valid_voter_ids = set()  # Stores valid voter IDs
pre_generated_voter_ids = []  # Stores generated voter IDs before the election

@app.route('/')
def index():
    return render_template('index.html', candidates=candidates, election_active=election_active, 
                           results_declared=results_declared, declared_winner=declared_winner,
                           candidate_info=candidate_info)

@app.route('/vote', methods=['POST'])
def vote():
    if not election_active:
        return jsonify({"success": False, "message": "Election is not active"}), 400

    voter_id = request.form.get('voter_id')
    candidate = request.form.get('candidate')

    if voter_id not in valid_voter_ids:
        return jsonify({"success": False, "message": "Invalid or already used voter ID"}), 400

    if voter_id in voters:
        return jsonify({"success": False, "message": "You have already voted"}), 400

    if candidate not in candidates:
        return jsonify({"success": False, "message": "Invalid candidate"}), 400

    voter_hash = hashlib.sha256(voter_id.encode()).hexdigest()
    new_block = Block(len(blockchain.chain), time.time(), {"voter_hash": voter_hash, "vote": candidate}, blockchain.get_latest_block().hash)
    blockchain.add_block(new_block)
    voters[voter_id] = voter_hash
    valid_voter_ids.remove(voter_id)  # Remove voter ID after voting

    return jsonify({"success": True, "message": "Vote cast successfully"}), 200

@app.route('/results')
def results():
    results = {candidate: 0 for candidate in candidates}
    for block in blockchain.chain[1:]:  # Skip genesis block
        if 'vote' in block.data:
            results[block.data['vote']] += 1
    return jsonify(results)

@app.route('/admin')
def admin():
    voter_hashes = list(voters.values())
    results = {candidate: 0 for candidate in candidates}
    for block in blockchain.chain[1:]:  # Skip genesis block
        if 'vote' in block.data:
            results[block.data['vote']] += 1
    
    # Calculate voting statistics
    total_voters = len(pre_generated_voter_ids)
    voted_count = len(voters)
    not_voted_count = total_voters - voted_count
    
    return render_template('admin.html', candidates=candidates, election_active=election_active, 
                           voter_hashes=voter_hashes, results=results, results_declared=results_declared,
                           pre_generated_voter_ids=pre_generated_voter_ids, candidate_info=candidate_info,
                           voted_count=voted_count, not_voted_count=not_voted_count, total_voters=total_voters)

@app.route('/start_election', methods=['POST'])
def start_election():
    global election_active, valid_voter_ids
    if election_active:
        return jsonify({"success": False, "message": "Election is already active"}), 400

    if not pre_generated_voter_ids:
        return jsonify({"success": False, "message": "No voter IDs generated! Generate them before starting."}), 400

    election_active = True
    valid_voter_ids = set(pre_generated_voter_ids)  # Assign generated voter IDs for use
    return jsonify({"success": True, "message": "Election started", "valid_voter_ids": list(valid_voter_ids)})

@app.route('/stop_election', methods=['POST'])
def stop_election():
    global election_active
    election_active = False
    return jsonify({"success": True, "message": "Election stopped"})

@app.route('/declare_results', methods=['POST'])
def declare_results():
    global results_declared, declared_winner
    results_declared = True
    results = {candidate: 0 for candidate in candidates}
    
    for block in blockchain.chain[1:]:  # Skip genesis block
        if 'vote' in block.data:
            results[block.data['vote']] += 1
    
    # Check if no votes were cast
    if all(votes == 0 for votes in results.values()):
        declared_winner = None
    else:
        declared_winner = max(results, key=results.get)

    return jsonify({
        "success": True,
        "results": results,
        "winner": declared_winner if declared_winner else "No votes were cast"
    })

@app.route('/generate_voter_id', methods=['POST'])
def generate_voter_id():
    global pre_generated_voter_ids

    if election_active or results_declared:
        return jsonify({"success": False, "message": "Cannot generate voter IDs while election is active or after results are declared"}), 400

    # Get parameters from request with defaults
    count = request.form.get('count', 25, type=int)
    start_number = request.form.get('start_number', 10001, type=int)
    
    # Generate sequential voter IDs
    pre_generated_voter_ids = [str(start_number + i) for i in range(count)]
    
    return jsonify({"success": True, "voter_ids": pre_generated_voter_ids})

@app.route('/blockchain')
def view_blockchain():
    chain_data = []
    for block in blockchain.chain:
        block_data = {
            "index": block.index,
            "timestamp": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(block.timestamp)),
            "data": block.data,
            "hash": block.hash,
            "previous_hash": block.previous_hash
        }
        chain_data.append(block_data)
    return render_template('blockchain.html', chain=chain_data)

if __name__ == '__main__':
    app.run(debug=True)

