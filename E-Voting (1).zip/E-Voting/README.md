# Decentralized E-Voting System

A secure, transparent, and immutable voting system built using blockchain technology.

## Features

- **Blockchain-Based**: All votes are stored in a blockchain, ensuring immutability and transparency
- **Secure Voting**: Each voter gets a unique ID that can only be used once
- **Admin Panel**: Manage elections, generate voter IDs, and view results
- **Blockchain Explorer**: View the entire blockchain and verify vote integrity
- **Real-time Results**: View election results in real-time

## Technology Stack

- **Backend**: Flask (Python)
- **Frontend**: HTML, CSS (Tailwind CSS), JavaScript
- **Storage**: In-memory blockchain implementation

## Setup and Installation

1. Clone the repository
2. Install the required dependencies:

